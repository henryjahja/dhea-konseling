<html>
        <head>
                <title>
                        Registrasi
                        </title>
        </head>
        <body>
        <center><b>Selamat Datang di halaman tambah user</b></center>
        
        <form method="post" action="adduser.php">
        <table>
        <tr>
        <td>Id_User</td> <td>: </td> <td><input type="text" size="20" maxlength="40" name="Id_User"><br></td>
        </tr>
        <td>Nama</td> <td>: </td><td><input type="text" size="20" maxlength="40" name="Nama"><br></td>
        </tr>
        <td>Email</td> <td>: <td><input type="text" size="20" maxlength="40" name="Email"><br></td>
        </tr>
        <td>Tgl_lahir</td>      <td>: </td><td><input type="text" size="20" maxlength="40" name="Tgl_lahir"><br></td>
        </tr>
        <td>Alamat</td>         <td>:</td> <td><input type="text" size="20" maxlength="40" name="Alamat"><br></td>
        </tr>
        <td>Telepon</td>        <td>: </td><td><input type="text" size="20" maxlength="40" name="Telepon"><br></td>
        </tr>
        <td>Foto</td>           <td>:</td> <td><input type="text" size="20" maxlength="40" name="Foto"><br></td>
        </tr>
        </table>
        <input type="submit" value="daftar"><br>
        </form>
        </body>
</html>