
<!-- forum.php -->

<!-- add -->
<a href='index.php?page=forum&act=add'>Tambah Topik</a>
<hr>
<!-- List Forum -->
<?php
	include 'sql.php';
	if (!isset($_GET['act']){
	$result = mysql_query("SELECT * FROM forum_q");
	?>
	<table border='0'>
	<?php
	while($row = mysql_fetch_array($result)){
		?>
		<tr>
		<td>Topik</td>
		<td> <a href='index.php?page=forum&act=view&id=<?php echo $row['id']; ?>'><?php echo $row['nama_topik'];?></a></td>
		</tr>
		
		<tr>
		<td>Username</td>
		<td> <?php echo $row['username'];?></td>
		</tr>
		
		<tr>
		<td>Waktu</td>
		<td> <?php echo $row['timestamp'];?></td>
		</tr>
		
		<tr>
		<td>Jawaban</td>
		<td> <?php echo $row['replies'];?></td>
		</tr>
		
		<?php
	}} else if ($_GET['act'] == 'view'){
			$result = mysql_query("SELECT * FROM  `forum_q` WHERE  `id` =" . $_GET['id']);
			while($row = mysql_fetch_array($result)){
				?><table border='0'>
				<tr>
				<td>Judul Topik</td>	<td> <?php echo $row['nama_topik']; ?> </td>
				<td>Penanya</td>		<td> <?php echo $row['username']; ?> </td>
				<td>Waktu</td>			<td> <?php echo $row['timestamp']; ?> </td>
				<td>Pertanyaan</td>		<td> <?php echo $row['question']; ?> </td>
				</tr>
				</table><?php
			}
			echo '<hr>';
			echo '<h3>Jawaban:</h3><br><table border="0">';
			$result = mysql_query("SELECT * FROM  `forum_a` WHERE  `q_id` =" . $_GET['id']);
			while($row = mysql_fetch_array($result)){
				?>
				<tr>
				<td style='width:250;'><?php echo $row['ans_username']; ?></td>
				</tr>
				<tr>
				<td style='width:250;'><?php echo $row['answer']; ?></td>
				</tr>
				<tr>
				<td style='width:250;'>Pada <?php echo $row['timestamp']; ?></td>
				</tr>
				<?php
			} ?>
			</table>
			<?php
		} else if ($_GET['act'] == 'add'){
			//$result = mysql_query("SELECT * FROM  `forum_q` WHERE  `id` =" . $_GET['id']);
			
		}
	
	?>
	</table>
<!-- End List Forum -->






<?php
mysql_close($con);
?>