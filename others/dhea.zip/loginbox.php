<center>
<h3>Anda belum login!</h3>
		
</center>
<form method="post" action="login.php">
<table width="80">
<tr> <td>Username: </td>
	 <td> <input type="text" size='15' name="usr"> </td> </tr>
<tr> <td>Password: </td>
	 <td> <input type="password" size='15' name="pwd"> </td>
	 
<tr> <td> <input type="submit" value="Login"> </td> <td> </td> </tr>
	 <tr> <td> <a href="user.php?page=regis">
			Daftar! </a>
		</td>
		<td align="right">
			<a href="user.php?page=forgot"> Lupa password </a> 
		</td>
		</tr>
</table>
	 