<form method='get' action='t2.php'>
<input type='date' name='date'>
<input type='submit'>
</form>

<a href="ymsgr:SendIM?jerome_107">
<img border=0 src="http://opi.yahoo.com/online?u=jerome_107&m=g&t=10"></a>