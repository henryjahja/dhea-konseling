
<!-- forum.php -->

<!-- add -->
<a href='index.php?page=forum&act=add'>Tambah Topik</a>
<hr>
<!-- List Forum -->
<?php
	include 'sql.php';
	if (!isset($_GET['act']){
	$result = mysql_query("SELECT * FROM forum_q");
	?>
	<table border='0'>
	<?php
	while($row = mysql_fetch_array($result)){
		?>
		<tr>
		<td>Topik</td>
		<td> <a href='index.php?page=forum&act=view&id=<?php echo $row['id']; ?>'><?php echo $row['nama_topik'];?></a></td>
		</tr>
		
		<tr>
		<td>Username</td>
		<td> <?php echo $row['username'];?></td>
		</tr>
		
		<tr>
		<td>Waktu</td>
		<td> <?php echo $row['timestamp'];?></td>
		</tr>
		
		<tr>
		<td>Jawaban</td>
		<td> <?php echo $row['replies'];?></td>
		</tr>
		
		<?php
	}} else if ($_GET['act'] == 'view'){
			$result = mysql_query("SELECT * FROM  `forum_q` WHERE  `id` =" . $_GET['id']);
			
		} else if ($_GET['act'] == 'add'){
			//$result = mysql_query("SELECT * FROM  `forum_q` WHERE  `id` =" . $_GET['id']);
			
		}
	
	?>
	</table>
<!-- End List Forum -->






<?php
mysql_close($con);
?>