<form method="get" action="cu.php">
Id_User :<input type="text" size="20" maxlength="40" name="Id_User">
</form>