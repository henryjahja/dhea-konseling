<form method="post" action="login.php">
<table width="80">
<tr> <td>Username: </td>
	 <td> <input type="text"name="usr"> </td> </tr>
<tr> <td>Password: </td>
	 <td> <input type="password"name="pwd"> </td> </td>
<tr> <td> <input type="submit"value="login"> </td> <td> </td> </tr>
	 <tr> <td> <a href="index,php?page=create_acc">
			Daftar! </a>
		</td>
		<td align="right">
			<a href="index.php?page=forgot"> Lupa password </a>
		</td>
		</tr>
</table>
	 