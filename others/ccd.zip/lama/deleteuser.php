masukan id yang ingin di delete
<br>
<form method="post" action="delusr.php">
Id_User :<input type="text" size="20" maxlength="40" name="\
">
</form>

