<!-- konseling.php -->
<?php
include 'sql.php';
if (!isset($_GET['kat'])){
$result = mysql_query("SELECT * FROM konselor");
} else if ($_GET['kat'] == 'pri'){
$result = mysql_query("SELECT * FROM konselor WHERE `bidang` LIKE  'pribadi'");
} else if ($_GET['kat'] == 'aka'){
$result = mysql_query("SELECT * FROM konselor WHERE `bidang` LIKE  'akademik'");
}

?>

	<table border='0' style="width:500px;">
	<tr><td><hr></td></tr>
	<?php
while($row = mysql_fetch_array($result))
  {
	?>
	<th rowspan='5'>
	 ini foto
	</th>
	<tr> <td> Nama </td> <td> <?php echo $row['nama']; ?></td></tr>
	<tr> <td> Email </td> <td> <a href="mailto:<?php echo $row['email']; ?>"> <?php echo $row['email']; ?> </a></td></>
	<tr> <td> Bidang Keahlian </td> <td> <?php echo $row['bidang']; ?></td></tr>
	<tr> <td> Chat </td> <td> <a href="ymsgr:SendIM?<?php echo $row['ym']; ?>">
<img border=0 src="http://opi.yahoo.com/online?u=<?php echo $row['ym']; ?>&m=g&t=2"></a></td></tr>
	<tr><td><hr></td></tr>
	<?php
  }
  ?>
  </table>
<?php

?>