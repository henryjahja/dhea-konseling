<?php
echo $_GET['date'];
echo '<br>';
$date = $_GET['date'];
echo $date[2];